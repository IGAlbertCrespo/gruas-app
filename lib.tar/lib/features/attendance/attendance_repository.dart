import '../../core/network/api_client.dart';
import '../../core/network/api_exception.dart';
import 'attendance_models.dart';
import 'offline_queue.dart';

String _two(int n) => n.toString().padLeft(2, '0');

/// Fecha/hora actual en UTC con el formato que espera Odoo: 'YYYY-MM-DD HH:MM:SS'.
String _odooNowUtc() => _fmtUtc(DateTime.now());

/// Formatea una fecha/hora concreta a UTC 'YYYY-MM-DD HH:MM:SS'.
String _fmtUtc(DateTime d) {
  final u = d.toUtc();
  return '${u.year.toString().padLeft(4, '0')}-${_two(u.month)}-${_two(u.day)} '
      '${_two(u.hour)}:${_two(u.minute)}:${_two(u.second)}';
}

/// Asistencia. Online -> llama al endpoint; sin red -> encola con offline_uuid.
class AttendanceRepository {
  AttendanceRepository(this.api, this.queue);
  final ApiClient api;
  final OfflineQueue queue;

  Future<List<BreakType>> breakTypes() async {
    final res = await api.getJson('/attendance/config');
    final list = (res['break_types'] ?? []) as List;
    return list.map((e) => BreakType.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<AttendanceState> currentState() async {
    final res = await api.getJson('/attendance/state');
    return AttendanceState.fromJson(res);
  }
  /// Servicios que impiden fichar la salida. null = no se pudo comprobar (sin red):
  /// en ese caso no se bloquea, la salida se encola como siempre.
  Future<List<TareaAbierta>?> tareasAbiertas() async {
    try {
      final res = await api.getJson('/attendance/state');
      final l = res['tareas_abiertas'];
      if (l is! List) return const [];
      return l.whereType<Map>().map(TareaAbierta.fromJson).toList();
    } on ApiException catch (e) {
      if (e.code == 'network_error') return null;
      rethrow;
    }
  }

  /// Ejecuta una operación; si falla por red, la encola y la devuelve como diferida.
  Future<Map<String, dynamic>> _op(
    String path,
    String type,
    String offlineUuid,
    Map<String, dynamic> data, {
    String? timestamp,
  }) async {
    final payload = {
      'offline_uuid': offlineUuid,
      'timestamp': timestamp ?? _odooNowUtc(),
      ...data,
    };
    try {
      return await api.postJson(path, data: payload);
    } on ApiException catch (e) {
      // Solo encolamos ante fallo de red, no ante errores de negocio.
      if (e.code == 'network_error') {
        await queue.enqueue(OfflineOp(
          offlineUuid: offlineUuid,
          type: type,
          timestamp: payload['timestamp'] as String,
          data: data,
        ));
        return {'success': true, 'queued': true};
      }
      rethrow;
    }
  }

  /// [at] permite abrir la jornada con una hora concreta (p.ej. la hora
  /// informada de inicio de la tarea cuando se ficha automáticamente).
  Future<Map<String, dynamic>> checkIn(String uuid, {double? lat, double? lng, DateTime? at}) =>
      _op('/attendance/check-in', 'check_in', uuid,
          {if (lat != null) 'latitude': lat, if (lng != null) 'longitude': lng},
          timestamp: at != null ? _fmtUtc(at) : null);

  Future<Map<String, dynamic>> checkOut(String uuid,
          {int? attendanceId, double? lat, double? lng, String? observaciones}) =>
      _op('/attendance/check-out', 'check_out', uuid, {
        if (attendanceId != null) 'attendance_id': attendanceId,
        if (lat != null) 'latitude': lat,
        if (lng != null) 'longitude': lng,
        if (observaciones != null && observaciones.isNotEmpty) 'observaciones': observaciones,
      });

  Future<Map<String, dynamic>> breakStart(String uuid, {int? attendanceId, int? breakTypeId}) =>
      _op('/attendance/break/start', 'break_start', uuid, {
        if (attendanceId != null) 'attendance_id': attendanceId,
        if (breakTypeId != null) 'break_type_id': breakTypeId,
      });

  Future<Map<String, dynamic>> breakEnd(String uuid, {int? breakId, int? attendanceId}) =>
      _op('/attendance/break/end', 'break_end', uuid, {
        if (breakId != null) 'break_id': breakId,
        if (attendanceId != null) 'attendance_id': attendanceId,
      });

  /// Pausa retroactiva completa (inicio + duración) para la comida que el chófer
  /// no fichó en tiempo real y que se incorpora a la jornada al fichar salida.
  /// El backend la marca con x_source='mobile_forced'. OJO: aquí el inicio NO es
  /// el momento de la operación, sino [start] (p. ej. las 14:00), que viaja en
  /// `data`; por eso el `timestamp` de la cola es irrelevante para esta op.
  Future<Map<String, dynamic>> breakForced(
    String uuid, {
    required DateTime start,
    required double durationHours,
    int? attendanceId,
    int? breakTypeId,
  }) =>
      _op('/attendance/break/forced', 'break_forced', uuid, {
        'start': _fmtUtc(start),
        'duration_hours': durationHours,
        if (attendanceId != null) 'attendance_id': attendanceId,
        if (breakTypeId != null) 'break_type_id': breakTypeId,
      });

  /// Sube todas las operaciones pendientes y confirma las aceptadas.
  Future<int> syncPending() async {
    final pending = await queue.pending();
    if (pending.isEmpty) return 0;
    final res = await api.postJson('/attendance/sync', data: {
      'operations': pending.map((o) => o.toJson()).toList(),
    });
    final results = (res['results'] ?? []) as List;
    final okUuids = results
        .where((r) => (r as Map)['success'] == true)
        .map((r) => (r as Map)['offline_uuid'].toString());
    await queue.ack(okUuids);
    return okUuids.length;
  }
}
/// Servicio pendiente que impide fichar la salida.
class TareaAbierta {
  final int id;
  final String name;
  final String? albaran;
  final String motivo; // sin_cerrar | sin_firmar

  const TareaAbierta({required this.id, required this.name, this.albaran, required this.motivo});

  bool get sinFirmar => motivo == 'sin_firmar';

  static TareaAbierta fromJson(Map j) => TareaAbierta(
        id: j['id'] as int,
        name: j['name']?.toString() ?? '',
        albaran: j['albaran']?.toString(),
        motivo: j['motivo']?.toString() ?? 'sin_cerrar',
      );
}